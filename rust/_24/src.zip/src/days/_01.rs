use std::io::BufRead;

pub fn solve(_f:Box<dyn BufRead>) -> (String,String) {
	(0.to_string(),0.to_string())
}
